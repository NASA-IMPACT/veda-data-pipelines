from cmr import CollectionQuery, GranuleQuery

api = GranuleQuery(mode="https://cmr.maap-project.org/search")

def lambda_handler(event, context):
    search_keyword = event['search_keyword']
    return api.keyword(search_keyword).get(1)

print(lambda_handler(event = {'search_keyword': 'GPM_3IMERGHH'}))
